using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

public class Filme
{
    public int id {get;set;}
    [Required(ErrorMessage = "informe o título.")]
    [StringLength(150)]
    [Display(Name = "título")]
    public string titulo {get;set;} = string.Empty;

    [Required(ErrorMessage = "informe o gênero.")]
    [StringLength(50)]
    [Display(Name = "Gênero")]
    public string Genero {get;set;} = string.Empty;

    [Range(1900,2100,ErrorMessage = "Ano entre 1900 e 2100.")]
    public int Ano {get;set;}

    [Range(1,600, ErrorMessage = "Ano entre 1900 e 2100.")]
    [Display(Name = "Duraçâo (min)")]
    public int Duracao {get;set;}

}